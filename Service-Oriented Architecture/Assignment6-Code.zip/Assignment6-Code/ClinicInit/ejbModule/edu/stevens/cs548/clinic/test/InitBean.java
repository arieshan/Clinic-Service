package edu.stevens.cs548.clinic.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import edu.stevens.cs548.clinic.domain.IPatientDAO;
import edu.stevens.cs548.clinic.domain.IPatientDAO.PatientExn;
import edu.stevens.cs548.clinic.domain.IProviderDAO;
import edu.stevens.cs548.clinic.domain.IProviderDAO.ProviderExn;
import edu.stevens.cs548.clinic.domain.ITreatmentDAO;
import edu.stevens.cs548.clinic.domain.Patient;
import edu.stevens.cs548.clinic.domain.PatientDAO;
import edu.stevens.cs548.clinic.domain.PatientFactory;
import edu.stevens.cs548.clinic.domain.Provider;
import edu.stevens.cs548.clinic.domain.Provider.ProviderType;
import edu.stevens.cs548.clinic.domain.ProviderDAO;
import edu.stevens.cs548.clinic.domain.ProviderFactory;
import edu.stevens.cs548.clinic.domain.Treatment;
import edu.stevens.cs548.clinic.domain.TreatmentDAO;
import edu.stevens.cs548.clinic.domain.TreatmentFactory;
import edu.stevens.cs548.clinic.service.dto.DrugTreatmentType;
import edu.stevens.cs548.clinic.service.dto.PatientDto;
import edu.stevens.cs548.clinic.service.dto.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.TreatmentDto;
import edu.stevens.cs548.clinic.service.dto.util.PatientDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDtoFactory;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientServiceLocal;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderServiceLocal;


/**
 * Session Bean implementation class InitBean
 */
@Singleton
@LocalBean
@Startup
public class InitBean {

	private static Logger logger = Logger.getLogger(InitBean.class.getCanonicalName());

	/**
	 * Default constructor.
	 */
	public InitBean() {
	}
    
	@Inject
	IPatientServiceLocal patientService;

	@Inject
	IProviderServiceLocal providerService;

	@PostConstruct
	private void init() {
		/*
		 * Put your testing logic here. Use the logger to display testing output in the server logs.
		 */
		logger.info("Your name here: Xiaohan Chang");

		try {
						
			/*
			 * TODO Clear the database and populate with fresh data.
			 * 
			 * TODO Do testing with patients, providers and treatments.
                         * Write results of testing to the logs.
			 */
			PatientDtoFactory patientDtoFactory = new PatientDtoFactory();
			ProviderDtoFactory providerDtoFactory = new ProviderDtoFactory();
			TreatmentDtoFactory treatmentDtoFactory = new TreatmentDtoFactory();
			
			PatientDto patientDto = new PatientDto();
			patientDto.setName("John");
			patientDto.setPatientId(28611L);

			long patientId = patientService.addPatient(patientDto);
			
			ProviderDto providerDto = new ProviderDto();
			providerDto.setName("Tommy");
			providerDto.setNpi(31811L);
			providerDto.setProviderSpec(ProviderDtoFactory.getSpecType(Provider.ProviderType.INTERNIST));
			long providerId = providerService.addProvider(providerDto);
			
			TreatmentDto treatmentDto = new TreatmentDto();
			DrugTreatmentType drug = new DrugTreatmentType();
			drug.setDosage(1.0f);
			drug.setDrug("anti-allergy");
			treatmentDto.setDiagnosis("allergy");
			treatmentDto.setPatient(patientId);
			treatmentDto.setProvider(providerId);
			treatmentDto.setDrugTreatment(drug);
			
			providerService.addTreatment(treatmentDto);
			
			List<Long> treatmentIds = providerService.getTreatments(providerId);
			
			PatientDto p = patientService.getPatient(patientId);
			logger.info("======== Added patient: " + p.getName() + " with id " + p.getId() + "   patientId " + patientId);
			
			TreatmentDto t = patientService.getTreatment(patientId, treatmentIds.get(0));
			logger.info("======== Added Treatment : " + t.getDiagnosis() + " with id " + treatmentIds.get(0));
			
			ProviderDto pr = providerService.getProvider(providerId);
			logger.info("======== Added Provider: " + pr.getName() + " with npi " + pr.getNpi() + " with type " + pr.getProviderSpec() + " with id " + pr.getId());
			
		} catch (PatientServiceExn e) {

			IllegalStateException ex = new IllegalStateException("Patient service.");
			ex.initCause(e);
			throw ex;
			
		} catch (ProviderServiceExn e) {

			IllegalStateException ex = new IllegalStateException("Provider service.");
			ex.initCause(e);
			throw ex;

		}	
	}

}
