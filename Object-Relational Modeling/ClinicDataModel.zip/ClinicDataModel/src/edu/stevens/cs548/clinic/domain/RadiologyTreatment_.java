package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.CollectionAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-29T15:02:35.512-0700")
@StaticMetamodel(RadiologyTreatment.class)
public class RadiologyTreatment_ extends Treatment_ {
	public static volatile CollectionAttribute<RadiologyTreatment, Date> treatmentDates;
}
