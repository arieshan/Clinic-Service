package edu.stevens.cs548.clinic.research.service;

import javax.ejb.Remote;

@Remote
public interface IResearchServiceRemote extends IResearchService {

}
