package edu.stevens.cs548.clinic.research.service;

import javax.ejb.Local;

@Local
public interface IResearchServiceLocal extends IResearchService {

}
